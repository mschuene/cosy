/**
 * Form
 */
public enum Shape {
    CIRCLE, HEXAGON, SQUARE
}
